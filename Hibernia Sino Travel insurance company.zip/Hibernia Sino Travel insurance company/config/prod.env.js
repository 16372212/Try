module.exports = {
    NODE_ENV: '"production"',
    BASE_API: '"https://api-prod"',
    APP_ORIGIN: '"https://wz.com"'
};
